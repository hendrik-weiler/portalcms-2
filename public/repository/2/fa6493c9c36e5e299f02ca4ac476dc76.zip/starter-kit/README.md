Download the ZIP to get started with Ember.js: <https://github.com/emberjs/starter-kit/downloads>
